package org.islasfilipinas;

public abstract class Forma {

	public abstract void dibuja();
}
