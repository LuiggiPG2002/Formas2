package org.islasfilipinas;

public class MainForma {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Forma dibuja1 = new Circulo();
		Forma dibuja2 = new Rectangulo();
		Forma dibuja3 = new Triangulo();
		
	
		dibuja1.dibuja();
		dibuja2.dibuja();
		dibuja3.dibuja();
		
	}

}
