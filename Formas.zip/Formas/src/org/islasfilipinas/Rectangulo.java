package org.islasfilipinas;

public class Rectangulo extends Forma{

	@Override
	public void dibuja() {
		// TODO Auto-generated method stub
		System.out.println("Estas dibujando un rectángulo");
	}
	

}	
