package org.islasfilipinas;

public class Triangulo extends Forma{

	@Override
	public void dibuja() {
		// TODO Auto-generated method stub
		System.out.println("Estas dibujando un triángulo");
	}

	
	}
